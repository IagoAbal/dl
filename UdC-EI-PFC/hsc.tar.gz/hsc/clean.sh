for o in $(find . -type f -name '*.o');
do
  rm -f $o
done

for hi in $(find . -type f -name '*.hi');
do
  rm -f $hi
done

for orig in $(find . -type f -name '*.orig');
do
  rm -f $orig
done
